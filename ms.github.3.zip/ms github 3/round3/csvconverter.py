### convert txt to csv
import csv

def convert_csv(infile,outfile):
    in_txt = csv.reader(open(infile, "r"), delimiter = '\t')
    #print in_txt 
    out_csv = csv.writer(open(outfile, 'w'))
    out_csv.writerows(in_txt)
    
